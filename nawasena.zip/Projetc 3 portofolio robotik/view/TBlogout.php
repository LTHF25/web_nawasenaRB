<?php
// Mulai sesi
session_start();

// Hapus semua data sesi
session_unset();

// Hancurkan sesi
session_destroy();

// Redirect ke halaman login
header("Location: ../project/app.php");
exit;
?>

<script src="../project/js/porto.js"></script>


